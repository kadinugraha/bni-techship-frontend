<template>
  <div id="app">
    <input v-model="username" placeholder="Username" />
    <input v-model="password" placeholder="Password" />
    <button v-on:click="login()">Login</button>
    <button v-on:click="register()">Register</button>
    <div v-html="hasil"></div>
    <input v-model="firstMidName" placeholder="First Mid Name"/>
    <input v-model="lastName" placeholder="Last Name"/>
    <button v-on:click="add()">Add Student</button>
  </div>
</template>

<script>
import axios from 'axios'

const BASE_URL = 'https://bnitechshipservices.azurewebsites.net';

export default {
  name: 'Student',
  data(){
    return{
      hasil: '',
      username: 'erick@actual-training.com',
      password: 'Indonesia@2020',
      firstMidName: '',
      lastName: '',
      listStudents: []
    }
  },
  async created(){
      await axios
        .get(BASE_URL+'/api/Students')
        .then(response => {
          this.listStudents = response.data;
          this.hasil = '';
          for(var i = 0; i < this.listStudents.length; i++){
            this.hasil += '<div>'+this.listStudents[i].firstMidName+' '+this.listStudents[i].lastName+'<div/>';
          }
        });
  },
  methods:{
    async login(){
      await axios
        .post(BASE_URL+'/api/Users/authenticate', {"username": this.username,"password": this.password})
        .then(response => {
          localStorage.TOKEN = response.data.token;
          console.log(localStorage.TOKEN);
        });
    },
    async register(){
      await axios
        .post(BASE_URL+'/api/Users/Register', {"username": this.username,"password": this.password})
        .then(response => {
          localStorage.TOKEN = response.data.token;
          console.log(localStorage.TOKEN);
        });
    },
    async add(){
      var student = {
        "lastName": this.lastName,
        "firstMidName": this.firstMidName
      };

      await axios
        .create({
            baseURL: BASE_URL,
            timeout: 10000,
            headers: {'Authorization': 'Bearer '+localStorage.TOKEN}
        })
        .post(BASE_URL+'/api/Students', student)
        .then(response => {
          
        });
    },
  }
}
</script>

<style>
</style>
