<template>
  <div id="app">
    <input v-model="kota" placeholder="Masukkan nama kota..."/>
    <button v-on:click="send()">Kirim</button>
    <div v-html="hasil"></div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'App',
  data(){
    return{
      kota: '',
      hasil: '',
      listCity: {}
    }
  },
  async created(){
      await axios
        .get('https://api.openweathermap.org/data/2.5/weather?q=Jakarta&appid=b43e6c9a1993620648e2ec05f7cfd925')
        .then(response => {
          this.listCity['Jakarta'] = {weather: response.data.weather[0].description};
          this.hasil = '';
          Object.keys(this.listCity).forEach(key=>{
              this.hasil += '<div>'+key+': '+this.listCity[key].weather;
            }
          );
        });
  },
  methods:{
    async send(){
      await axios
        .get('https://api.openweathermap.org/data/2.5/weather?q='+this.kota+'&appid=b43e6c9a1993620648e2ec05f7cfd925')
        .then(response => {
          this.listCity[this.kota] = {weather: response.data.weather[0].description};
          this.hasil = '';
          Object.keys(this.listCity).forEach(key=>{
              this.hasil += '<div>'+key+': '+this.listCity[key].weather;
            }
          );
        });
    }
  }
}
</script>

<style>
</style>
