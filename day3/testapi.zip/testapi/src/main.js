import Vue from 'vue'
import App from './Student.vue' //App student
//import App from './App.vue' //App cuaca

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
