<template>
    <div>
        <div v-for="item in items" :key="item">
            {{item}}
            <button v-on:click="add(item)">Tambah</button>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                items: ['PS5', 'XBox', 'Nintendo Switch']
            }
        },
        methods:{
            add(nama){
                this.$store.commit('addtocart',nama);
            }
        }
    }
</script>

<style lang="scss" scoped>

</style>