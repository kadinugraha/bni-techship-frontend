<template>
    <div>
        <div v-for="item in items" :key="item">
            {{item}}
            <button v-on:click="add(item)">Tambah</button>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return{
                items: ['Asus', 'MSI', 'Lenovo']
            }
        },
        methods:{
            add(nama){
                this.$store.commit('addtocart',nama);
            }
        }
    }
</script>

<style lang="scss" scoped>

</style>