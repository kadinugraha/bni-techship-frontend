<template>
    <div>
        Alamat saya di Jalan Diponegoro No. 1
    </div>
</template>