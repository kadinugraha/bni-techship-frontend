<template>
    <div>
        Kontak Saya: 01234567890
    </div>
</template>