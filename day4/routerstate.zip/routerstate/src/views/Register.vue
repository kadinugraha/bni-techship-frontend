<template>
    <div>
        <input placeholder="Full Username"/>
        <input placeholder="Username"/><br/>
        <input placeholder="Password"/>
        <input placeholder="Confirm Password"/><br/>
        <button>Register</button>
    </div>
</template>

<script>
    export default {
        name: 'Register'
    }
</script>