<template>
    <div>
        <div>Aplikasi ini dibuat oleh saya {{$route.params.nama}}</div>
        <router-link v-bind:to="'/about/'+$route.params.nama+'/contact'">Kontak</router-link> |
        <router-link v-bind:to="'/about/'+$route.params.nama+'/address'">Alamat</router-link>
        <router-view />
    </div>
</template>

<script>
    export default {
        name: 'About'
    }
</script>