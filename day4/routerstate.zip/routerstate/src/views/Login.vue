<template>
    <div>
        <input v-model="username" placeholder="Username"/>
        <input placeholder="Password"/>
        <button v-on:click="login(username)">Login</button>
    </div>
</template>

<script>
    export default {
        name: 'Login',
        data(){
            return{
                username: ''
            }
        },
        methods:{
            login(username){
                this.$router.push('/about/'+username);
            }
        }
    }
</script>