<template>
    <div>
        <input v-model="keyword" v-on:keyup="search(keyword)"/>
        <div v-html="hasil"></div>
    </div>
</template>

<script>
    export default {
        name: 'SearchPenduduk',
        props: ['penduduk'],
        data(){
            return{
                keyword: '',
                hasil: ''
            }
        },
        methods: {
            search(keyword){
                this.hasil = '';
                for(var i = 0; i < this.penduduk.length; i++){
                    if(this.penduduk[i].nama.includes(keyword)){
                        this.hasil += '<div>'+this.penduduk[i].nama+' - '+this.penduduk[i].usia+'</div>';
                    }
                }
            }
        }
    }
</script>

<style lang="scss" scoped>

</style>