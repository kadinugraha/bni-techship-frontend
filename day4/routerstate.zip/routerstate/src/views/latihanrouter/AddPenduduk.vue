<template>
    <div>
        <input v-model="nama" placeholder="Nama"/>
        <input v-model="usia" placeholder="Usia"/>
        <button v-on:click="add(nama, usia)">Tambahkan</button>
    </div>
</template>

<script>
    export default {
        name: 'AddPenduduk',
        props: ['penduduk'],
        data(){
            return{
                nama: '',
                usia: ''
            }
        },
        methods: {
            add(nama, usia){
                this.penduduk.push({nama, usia});
                console.log(this.penduduk);
            }
        }
    }
</script>

<style lang="scss" scoped>

</style>