<template>
  <div id="app">
    <router-link to="/">Login</router-link> | 
    <router-link to="/register">Register</router-link> | 
    <router-link to="/about">About</router-link>
    <button v-on:click="prev()">Prev</button>
    <button v-on:click="next()">Next</button>

    <router-view />
  </div>
</template>

<script>
export default{
  name: 'App',
  methods:{
    prev(){
      this.$router.go(-1);
    },
    next(){
      this.$router.go(1);
    }
  }
}
</script>
