<template>
    <div>
        <button v-on:click="tambah()">Tambah</button>
    </div>
</template>

<script>
    export default {
        methods: {
            tambah(){
                this.$store.commit('increment');
            }
        }
    }
</script>

<style lang="scss" scoped>

</style>