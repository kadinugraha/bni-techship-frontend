<template>
    <div>
        <div>Isi Cart:</div>
        <div v-for="item in $store.state.cart" :key="item.nama">{{item.nama}} x {{item.jumlah}}</div>
        <router-link to="/handphone">Handphone</router-link> |
        <router-link to="/laptop">Laptop</router-link> |
        <router-link to="/game">Game</router-link>

        <router-view />
    </div>
</template>

<script>
</script>

<style lang="scss" scoped>

</style>