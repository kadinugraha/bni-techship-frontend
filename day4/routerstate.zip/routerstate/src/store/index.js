import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    count: 0,
    cart: []
  },
  mutations: {
    increment(state){
      state.count++;
    },
    addtocart(state, nama){
      var newItem = true;
      for(var i = 0; i < state.cart.length; i++){
        if(state.cart[i].nama == nama){
          state.cart[i].jumlah++;
          newItem = false;
          break;
        }
      }

      if(newItem){
        state.cart.push({nama: nama, jumlah: 1});
      }
    }
  },
  actions: {
    increment(context){
      context.commit('increment');
    }
  },
  modules: {
  }
})
