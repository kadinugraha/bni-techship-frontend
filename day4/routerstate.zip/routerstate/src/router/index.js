import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import About from '../views/About.vue'
import Contact from '../views/about/Contact.vue'
import Address from '../views/about/Address.vue'
import AddPenduduk from '../views/latihanrouter/AddPenduduk.vue'
import SearchPenduduk from '../views/latihanrouter/SearchPenduduk.vue'
import Laptop from '../views/latihanvuex/Laptop.vue'
import Handphone from '../views/latihanvuex/Handphone.vue'
import Game from '../views/latihanvuex/Game.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: Login
  },
  {
    path: '/register',
    component: Register
  },
  {
    path: '/about/:nama',
    component: About,
    children: [
      {
        path: 'contact',
        component: Contact
      },
      {
        path: 'address',
        component: Address
      },
    ]
  },
  {
    path: '/add',
    component: AddPenduduk
  },
  {
    path: '/search',
    component: SearchPenduduk
  },
  {
    path: '/laptop',
    component: Laptop
  },
  {
    path: '/handphone',
    component: Handphone
  },
  {
    path: '/game',
    component: Game
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
