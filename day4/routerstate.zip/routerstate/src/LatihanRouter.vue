<template>
    <div>
        <router-link to="/add">Add Penduduk</router-link> |
        <router-link to="/search">Search Penduduk</router-link>

        <router-view v-bind:penduduk="listPenduduk" />
    </div>
</template>

<script>
    export default {
        name: 'LatihanRouter',
        data(){
            return{
                listPenduduk: []
            }
        }
    }
</script>

<style lang="scss" scoped>

</style>